export const API_URL = 'https://forkify-api.jonas.io/api/v2/recipes/';
export const TIMEOUT_SEC = 10;
export const MODAL_CLOSE_SEC = 2.5;
export const RES_PER_PAGE = 10;
export const FIRST_PAGE_DISPLAYS = 1;
export const KEY = '249852fd-147a-4da7-941b-0598c186b3a2';
